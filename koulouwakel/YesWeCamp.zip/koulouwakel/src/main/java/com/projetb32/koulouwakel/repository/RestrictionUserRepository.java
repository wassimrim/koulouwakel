package com.projetb32.koulouwakel.repository;

import com.projetb32.koulouwakel.entity.ConstraintUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestrictionUserRepository extends JpaRepository<ConstraintUser,Long> {

}
