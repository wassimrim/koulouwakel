package com.projetb32.koulouwakel.repository;

import com.projetb32.koulouwakel.entity.ConstraintCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestrictionCategoryRepository extends JpaRepository<ConstraintCategory,Long> {

}
