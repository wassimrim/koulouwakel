
package com.projetb32.koulouwakel.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.time.LocalDate;

/*@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FridgeIngredient {*/

/*

    @EmbeddedId
    protected FridgeIngredientPk fridgeIngredientPk ;


    private LocalDate dlc ;

    private float quantity ;

    public FridgeIngredient(FridgeIngredientPk fridgeIngredientPk) {
        super();
    }
}
*/