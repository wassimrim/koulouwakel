package com.projetb32.koulouwakel.repository;


import com.projetb32.koulouwakel.entity.ConstraintTag;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestrictiontagRepository extends JpaRepository<ConstraintTag, Long>
 {

}
