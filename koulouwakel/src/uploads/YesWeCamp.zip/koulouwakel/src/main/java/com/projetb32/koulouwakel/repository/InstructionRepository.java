package com.projetb32.koulouwakel.repository;

import com.projetb32.koulouwakel.entity.Instruction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstructionRepository extends JpaRepository <Instruction,Long> {

}
