package com.projetb32.koulouwakel.repository;

import com.projetb32.koulouwakel.entity.ConstraintIngredient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestrictioningredientRepository extends JpaRepository<ConstraintIngredient,Long> {

}
