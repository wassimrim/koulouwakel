/*package com.projetb32.koulouwakel.repository;

import com.projetb32.koulouwakel.entity.FridgeIngredient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FridgeIngredientRepository extends JpaRepository <FridgeIngredient, Long> {
}
*/